scnShortcodeMeta={
	attributes:[
		{
			label:"Alert Content",
			id:"content",
			isRequired:true
		},
         {
		label:"Title",
		id:"title",
		
   		 },
         {
		label:"Style",
		id:"style",
		help:"", 
		controlType:"select-control", 
		selectValues:['default','success', 'error', 'info', 'warning', 'grey']
   		 },
        
         
		],
		
		shortcode:"alert"
		
};