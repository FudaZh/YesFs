scnShortcodeMeta={
	attributes:[
         {
		label:"Select form for dropcaps",
		id:"form",
		controlType:"select-control", 
		selectValues:['square', 'circle', 'no-form']
		 },
		 {
		label:"Background form color",
		id:"color" 
		
		 },
		 {
		label:"Font color",
		id:"fontcolor" 
         }
		],
		defaultContent: "A",
		shortcode:"dropcaps"
		
};