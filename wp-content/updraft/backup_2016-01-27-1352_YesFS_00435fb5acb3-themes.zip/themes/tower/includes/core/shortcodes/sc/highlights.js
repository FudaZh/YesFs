scnShortcodeMeta={
	attributes:[
		

        {
        	label:"Type the link for the highlighted text",
        	id:"link",

        },
     
        ],


        defaultContent: "Add your text here",
        shortcode:"highlights"

    };    