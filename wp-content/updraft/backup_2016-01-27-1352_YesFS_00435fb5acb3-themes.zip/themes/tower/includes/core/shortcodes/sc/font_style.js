scnShortcodeMeta={
	attributes:[
		 {
		label:"Font Size (with px)",
		id:"fontsize" 
		
		 },
		 {
		label:"Font Weight (ex: 300,400,500,600)",
		id:"fontweight" 
         },
         {
		label:"Line Height (ex: 24px)",
		id:"lineheight" 
         },
         {
		label:"Font Color (ex: #ffffff)",
		id:"fontcolor" 
         },
		],
		defaultContent: "A Short Text",
		shortcode:"font_style"
		
};